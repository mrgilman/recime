require 'spec_helper'

describe Recipe do
  pending "add some examples to (or delete) #{__FILE__}"
end
