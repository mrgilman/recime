require 'spec_helper'

describe FriendshipsController do

end
