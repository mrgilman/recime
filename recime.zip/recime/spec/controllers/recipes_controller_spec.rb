require 'spec_helper'

describe RecipesController do

end
