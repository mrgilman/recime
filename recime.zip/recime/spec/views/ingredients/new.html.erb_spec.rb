require 'spec_helper'

describe "ingredients/new.html.erb" do
  pending "add some examples to (or delete) #{__FILE__}"
end
