class IngredientsController < ApplicationController
end
