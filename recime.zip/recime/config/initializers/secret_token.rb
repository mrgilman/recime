# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
Recime::Application.config.secret_token = '2b8998e3757cf7710e49d751f315fcaf924395981dbfec61f0803daf9f292b647e81718233aa983cf29f7faf241592a8c2b75fc638618aac06f39d3690261374'
